﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MosquitoGame
{
    public partial class Level1 : Form
    {
        float timeLeft = 10f;
        int Kill = 0;
        int spawnTime = 0;
        int spawnLimit = 30;
        List<Mosquito> mosquito_list = new List<Mosquito>();
        Random rand = new Random();
        Image[] Mosquito_images = { Properties.Resources.NCjs };

        

        public Level1()
        {
            InitializeComponent();
        }

        private void Level1_Load(object sender, EventArgs e)
        {

        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            Timecount.Text = "Time Left: " + timeLeft.ToString("#") + ".s";
            label2Kill.Text = "Kill: " + Kill;
            timeLeft -= 0.03f;
            if (mosquito_list.Count < spawnLimit)
            {
                spawnTime--;
                if (spawnTime < 1)
                {
                    MakeMosquito();
                    spawnTime = spawnLimit;
                }
            }
            foreach (Mosquito  mosquito in mosquito_list )
            {
                mosquito.MoveMosquito();
                mosquito.positionX += mosquito.speedX;
                if (mosquito.positionX < 0 || mosquito.positionX + mosquito.width > this.ClientSize.Width)
                {
                    mosquito.speedX = -mosquito.speedX;
                    if (mosquito.positionX < 0)
                    {
                        mosquito.positionX = mosquito.positionX + 10;
                    }
                    else if (mosquito.positionX + mosquito.width > this.ClientSize.Width)
                    {
                        mosquito.positionX = mosquito.positionX - 10;
                    }
                }
                mosquito.positionY += mosquito.speedY;
                if (mosquito.positionY < 0 || mosquito.positionY + mosquito.height > this.ClientSize.Height - 50)
                {
                    mosquito.speedY = -mosquito.speedY;
                    if (mosquito.positionY < 0)
                    {
                        mosquito.positionY = mosquito.positionY + 10;
                    }
                    else if (mosquito.positionY + mosquito.height > this.ClientSize.Height - 50)
                    {
                       mosquito.positionY = mosquito.positionY - 10;
                    }
                }
            }
            if (timeLeft < 1)
            {
                GameOver();
            }
            this.Invalidate();
        }
    

        private void FormClickEvent(object sender, EventArgs e)
        {
            foreach (Mosquito mosquito in mosquito_list.ToList())
            {
                MouseEventArgs mouse = (MouseEventArgs)e;
                if (mouse.X >=mosquito.positionX && mouse.Y >= mosquito.positionY && mouse.X < mosquito.positionX + mosquito.width && mouse.Y < mosquito.positionY + mosquito.height)
                {
                    mosquito_list.Remove(mosquito);
                    Kill++;
                }
            }

        }

        private void FormPaintEvent(object sender, PaintEventArgs e)
        {
            ImageAnimator.UpdateFrames();
            foreach (Mosquito mosquito in mosquito_list)
            {
                e.Graphics.DrawImage(mosquito.Mosquito_image, mosquito.positionX, mosquito.positionY, mosquito.width, mosquito.height);
            }
        }
        public void MakeMosquito()
        {
            int i = rand.Next(Mosquito_images.Length);
            Mosquito newMosquito = new Mosquito();
            newMosquito.Mosquito_image = Mosquito_images[i];
            newMosquito.positionX = rand.Next(50, this.ClientSize.Width - 200);
            newMosquito.positionY = rand.Next(50, this.ClientSize.Height - 200);
            mosquito_list.Add(newMosquito);
            ImageAnimator.Animate(newMosquito.Mosquito_image, this.OnFrameChangedHandler);

        }

        private void OnFrameChangedHandler(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        public void RestartGame()
        {
            this.Invalidate();
            mosquito_list.Clear();
            Kill = 0;
            timeLeft = 60f;
            spawnTime = 0;
            Timecount.Text = "Time: 00";
            label2Kill.Text = "Caught: 0";
            GameTimer.Start();
        }
        public void GameOver()
        {
            GameTimer.Stop();
            MessageBox.Show("Times Up!!, You've Killed " + Kill + " . Click ok mosquitoes to try again.", "MOO says: ");
            RestartGame();
        
    }
    }
}
