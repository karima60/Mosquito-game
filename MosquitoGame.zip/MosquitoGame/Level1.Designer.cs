﻿
namespace MosquitoGame
{
    partial class Level1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Timecount = new System.Windows.Forms.Label();
            this.label2Kill = new System.Windows.Forms.Label();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 416);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(683, 39);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Timecount
            // 
            this.Timecount.AutoSize = true;
            this.Timecount.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Timecount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Timecount.Location = new System.Drawing.Point(9, 420);
            this.Timecount.Name = "Timecount";
            this.Timecount.Size = new System.Drawing.Size(165, 29);
            this.Timecount.TabIndex = 1;
            this.Timecount.Text = "Time left : 00";
            // 
            // label2Kill
            // 
            this.label2Kill.AutoSize = true;
            this.label2Kill.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2Kill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2Kill.Location = new System.Drawing.Point(545, 421);
            this.label2Kill.Name = "label2Kill";
            this.label2Kill.Size = new System.Drawing.Size(86, 29);
            this.label2Kill.TabIndex = 2;
            this.label2Kill.Text = "Kill : 0";
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.GameTimerEvent);
            // 
            // Level1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::MosquitoGame.Properties.Resources.Screenshot_2024_01_02_182809;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(682, 455);
            this.Controls.Add(this.label2Kill);
            this.Controls.Add(this.Timecount);
            this.Controls.Add(this.pictureBox1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DoubleBuffered = true;
            this.Name = "Level1";
            this.Text = "Level1";
            this.Load += new System.EventHandler(this.Level1_Load);
            this.Click += new System.EventHandler(this.FormClickEvent);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FormPaintEvent);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Timecount;
        private System.Windows.Forms.Label label2Kill;
        private System.Windows.Forms.Timer GameTimer;
    }
}