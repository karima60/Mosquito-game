﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MosquitoGame
{
    public partial class Spalsh : Form
    {
        public Spalsh()
        {
            InitializeComponent();
        }

        private void Spalsh_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
        int startPoint = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            startPoint += 2;
            progressBar1.ForeColor = Color.Red;
            progressBar1.Value = startPoint;
            if (progressBar1.Value == 100)
            {
                progressBar1.Value = 0;
                timer1.Stop();
                Start Opento = new Start();
                this.Hide();
                Opento.Show();
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
